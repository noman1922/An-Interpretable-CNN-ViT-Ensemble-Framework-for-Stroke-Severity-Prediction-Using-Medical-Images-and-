# Images Needed

Add these files before publishing if you want all photos to show:

- hero.jpg
- speaker-1.jpg
- speaker-2.jpg
- speaker-3.jpg
- speaker-4.jpg
