# AI Challenge Prompt

## Section Idea

DEVCONF Connection Hub

## Prompt Used

"Design a unique networking-focused section for a developer conference website called DEVCONF 2026. The section should help communicate how attendees can connect with developers, founders, mentors, and open-source communities. Create three visually consistent feature cards for finding tech circles, joining short idea-match networking sessions, and discovering open-source projects. The design must use only HTML5 and CSS3 with no JavaScript or CSS frameworks. Use a modern blue and purple technology theme, rounded cards, subtle borders, and a clear call-to-action. The section should visually match a clean developer conference landing page."

## AI Contribution

AI was used to brainstorm the networking section concept, improve the section content, and suggest the visual card layout for the DEVCONF Connection Hub.
